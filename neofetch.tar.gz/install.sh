#!/bin/sh
# YAPM install script
cp ./bin/* /bin
